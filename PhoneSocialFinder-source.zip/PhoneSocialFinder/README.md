# Phone Social Finder (Android)

Aplikasi Android sederhana untuk membuka pencarian publik berdasarkan nomor telepon. Aplikasi ini tidak melakukan scraping otomatis, tidak mengakses akun privat, dan tidak mengklaim bahwa hasil pencarian membuktikan identitas pemilik nomor.

## Fitur
- Input nomor dengan normalisasi sederhana untuk format Indonesia (08… menjadi +628…).
- Google exact-match search.
- Tautan pencarian web publik untuk Facebook, Instagram, TikTok, Telegram, Bing, serta pembukaan situs Truecaller.
- Tidak meminta izin kontak, SMS, lokasi, atau akses akun.

## Build APK
1. Buka folder `PhoneSocialFinder` di Android Studio versi yang mendukung Android Gradle Plugin 8.7.3.
2. Biarkan Gradle melakukan sinkronisasi (internet mungkin diperlukan untuk mengunduh dependensi build).
3. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

Untuk distribusi publik, buat APK release yang ditandatangani dengan kunci milik Anda dan tambahkan kebijakan privasi yang dapat diakses publik. Ikuti kebijakan Google Play dan hukum perlindungan data yang berlaku.

## Catatan hasil
Platform tidak selalu mengindeks nomor telepon. Akun bisa tidak muncul meskipun ada, atau hasil bisa merujuk pada orang berbeda. Gunakan hanya untuk tujuan yang sah dan hormati privasi.
