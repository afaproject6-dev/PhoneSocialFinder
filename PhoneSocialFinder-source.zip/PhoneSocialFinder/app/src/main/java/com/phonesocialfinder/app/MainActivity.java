package com.phonesocialfinder.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private EditText phoneInput;
    private TextView status;
    private int blue = Color.rgb(36, 87, 214);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(23, 59, 145));
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(24), dp(22), dp(28));
        root.setBackgroundColor(Color.rgb(246, 248, 252));
        scroll.addView(root);

        TextView logo = new TextView(this);
        logo.setText("⌕"); logo.setTextSize(40); logo.setTextColor(blue); logo.setGravity(Gravity.CENTER);
        root.addView(logo, new LinearLayout.LayoutParams(-1, dp(58)));

        TextView title = new TextView(this);
        title.setText("Phone Social Finder"); title.setTextSize(25); title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.rgb(24, 35, 60)); title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("Cari jejak nomor di sumber publik"); subtitle.setTextSize(14); subtitle.setTextColor(Color.DKGRAY); subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subP = matchWrap(); subP.bottomMargin = dp(22); subP.topMargin = dp(6); root.addView(subtitle, subP);

        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(16), dp(18), dp(16), dp(16));
        card.setBackground(round(Color.WHITE, 18));
        root.addView(card, matchWrap());

        TextView label = new TextView(this); label.setText("Nomor telepon"); label.setTextSize(14); label.setTypeface(null, Typeface.BOLD); label.setTextColor(Color.rgb(36, 46, 67));
        card.addView(label, matchWrap());
        phoneInput = new EditText(this); phoneInput.setSingleLine(true); phoneInput.setTextSize(16); phoneInput.setHint("Contoh: +6281234567890"); phoneInput.setInputType(3);
        phoneInput.setPadding(dp(12), 0, dp(12), 0); phoneInput.setBackground(round(Color.rgb(246, 248, 252), 10));
        LinearLayout.LayoutParams inputP = matchWrap(); inputP.topMargin = dp(8); inputP.bottomMargin = dp(12); card.addView(phoneInput, new LinearLayout.LayoutParams(-1, dp(52)));

        Button search = button("Cari di Google", true); card.addView(search, fullButton());
        search.setOnClickListener(v -> searchGoogle());

        TextView resultsLabel = new TextView(this); resultsLabel.setText("Pencarian platform"); resultsLabel.setTextSize(17); resultsLabel.setTypeface(null, Typeface.BOLD); resultsLabel.setTextColor(Color.rgb(24, 35, 60));
        LinearLayout.LayoutParams rl = matchWrap(); rl.topMargin = dp(22); rl.bottomMargin = dp(10); root.addView(resultsLabel, rl);

        addPlatform(root, "Facebook", "Cari nomor di halaman publik Facebook", "https://www.google.com/search?q=site%3Afacebook.com+%22", "%22");
        addPlatform(root, "Instagram", "Cari hasil publik Instagram", "https://www.google.com/search?q=site%3Ainstagram.com+%22", "%22");
        addPlatform(root, "TikTok", "Cari hasil publik TikTok", "https://www.google.com/search?q=site%3Atiktok.com+%22", "%22");
        addPlatform(root, "Telegram", "Cari halaman publik terkait Telegram", "https://www.google.com/search?q=site%3At.me+%22", "%22");
        addPlatform(root, "Truecaller", "Buka situs resmi untuk pemeriksaan nomor", "https://www.truecaller.com/search/", "");
        addPlatform(root, "Bing", "Cari nomor di mesin pencari lain", "https://www.bing.com/search?q=%22", "%22");

        status = new TextView(this); status.setText("Privasi: aplikasi ini hanya membuka pencarian publik. Hasil tidak membuktikan kepemilikan akun."); status.setTextSize(12); status.setTextColor(Color.rgb(90, 99, 115)); status.setPadding(dp(2), dp(18), dp(2), 0);
        root.addView(status, matchWrap());
        setContentView(scroll);
    }

    private void addPlatform(LinearLayout root, String name, String description, String prefix, String suffix) {
        LinearLayout item = new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setPadding(dp(14), dp(12), dp(14), dp(12)); item.setBackground(round(Color.WHITE, 14));
        LinearLayout.LayoutParams p = matchWrap(); p.bottomMargin = dp(9); root.addView(item, p);
        TextView t = new TextView(this); t.setText(name); t.setTextSize(16); t.setTypeface(null, Typeface.BOLD); t.setTextColor(Color.rgb(30, 42, 66)); item.addView(t, matchWrap());
        TextView d = new TextView(this); d.setText(description); d.setTextSize(12); d.setTextColor(Color.GRAY); LinearLayout.LayoutParams dp = matchWrap(); dp.topMargin = dp(3); item.addView(d, dp);
        Button b = button("Buka pencarian", false); LinearLayout.LayoutParams bp = fullButton(); bp.topMargin = dp(8); item.addView(b, bp);
        b.setOnClickListener(v -> {
            String number = normalizedNumber(); if (number == null) return;
            String encoded = URLEncoder.encode(number, StandardCharsets.UTF_8);
            String url;
            if (name.equals("Truecaller")) url = prefix + encoded;
            else url = prefix + encoded + suffix;
            openUrl(url);
        });
    }

    private void searchGoogle() {
        String number = normalizedNumber(); if (number == null) return;
        String query = URLEncoder.encode("\"" + number + "\" OR \"" + number.replaceFirst("^\\+", "") + "\"", StandardCharsets.UTF_8);
        openUrl("https://www.google.com/search?q=" + query);
    }

    private String normalizedNumber() {
        String raw = phoneInput.getText().toString().trim();
        String number = raw.replaceAll("[\\s()\\-]", "");
        if (number.startsWith("00")) number = "+" + number.substring(2);
        if (number.matches("^08[0-9]+$")) number = "+62" + number.substring(1);
        if (number.matches("^8[0-9]+$")) number = "+62" + number;
        if (!number.matches("^\\+?[0-9]{7,15}$")) {
            Toast.makeText(this, "Masukkan nomor yang valid, misalnya +6281234567890", Toast.LENGTH_LONG).show(); return null;
        }
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(phoneInput.getWindowToken(), 0);
        return number;
    }

    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { Toast.makeText(this, "Tidak dapat membuka browser.", Toast.LENGTH_SHORT).show(); }
    }
    private Button button(String text, boolean primary) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(14); b.setTypeface(null, Typeface.BOLD);
        b.setTextColor(primary ? Color.WHITE : blue); b.setBackground(round(primary ? blue : Color.rgb(235, 241, 255), 12));
        return b;
    }
    private GradientDrawable round(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private LinearLayout.LayoutParams fullButton() { return new LinearLayout.LayoutParams(-1, dp(48)); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
